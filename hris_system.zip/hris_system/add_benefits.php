<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$employees = $conn->query("SELECT emp_id, CONCAT(first_name, ' ', last_name) AS full_name FROM employees ORDER BY first_name ASC");

$message = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emp_id = intval($_POST['emp_id']);
    $health_plan = $_POST['health_plan'] ?? '';
    $retirement_plan = $_POST['retirement_plan'] ?? '';
    $insurance_type = $_POST['insurance_type'] ?? '';
    $dependents = intval($_POST['dependents'] ?? 0);

    $stmt = $conn->prepare("INSERT INTO benefits (emp_id, health_plan, retirement_plan, insurance_type, dependents) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isssi", $emp_id, $health_plan, $retirement_plan, $insurance_type, $dependents);

    if ($stmt->execute()) {
        $message = "✅ Benefits successfully assigned.";
    } else {
        $error = "❌ Error: " . $stmt->error;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Benefits</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <style>
        /* --- Enhanced Styling --- */
        .main-content {
            padding: 30px 20px;
            background-color: #f8f9fc;
            min-height: calc(100vh - 120px);
        }

        .main-content h3 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333;
        }

        .form-container {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            padding: 30px 40px;
            max-width: 600px;
            margin: 0 auto;
        }

        .form-container label {
            display: block;
            font-weight: 600;
            margin-bottom: 6px;
            color: #444;
        }

        .form-container input[type="text"],
        .form-container input[type="number"],
        .form-container select {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 18px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
            transition: border 0.2s ease;
        }

        .form-container input:focus,
        .form-container select:focus {
            border-color: #007bff;
            outline: none;
        }

        .btn {
            display: inline-block;
            background: #007bff;
            color: #fff;
            font-weight: 600;
            padding: 10px 18px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.2s ease;
        }

        .btn:hover {
            background: #0056b3;
        }

        .alert {
            margin-bottom: 20px;
            padding: 12px 18px;
            border-radius: 6px;
            font-weight: 500;
        }

        .alert.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        hr.sidebar-separator {
            border: none;
            border-top: 1px solid #ddd;
            margin: 12px 0;
        }

        .dropdown-content {
            display: none;
            list-style: none;
            padding-left: 15px;
        }

        .dropdown.active .dropdown-content {
            display: block;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<div class="sub-navbar">
    <ul>

        <li><a href="dashboard.php">Dashboard</a></li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_leave.php">Leave Form</a></li>
                <li><a href="leave_requests.php">Leave Requests</a></li>
            </ul>
        </li>

        <!-- <li class="dropdown">
            <a href="#" class="active" onclick="toggleDropdown(event)">Payroll ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_payroll.php">Add Payroll</a></li>
                <li><a href="payroll.php">Payroll List</a></li>
                <li><a href="add_benefits.php" class="active">Add Benefits</a></li>
                <li><a href="benefits_list.php">Benefits List</a></li>
            </ul>
        </li> -->

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_job.php">Add Job</a></li>
                <li><a href="job_list.php">Jobs</a></li>
                <li><a href="add_candidate.php">Add Candidate</a></li>
                <li><a href="candidate_list.php">Candidates</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
            <ul class="dropdown-content">
                <li><a href="reports.php">Reports</a></li>
                <li><a href="accounts.php">Accounts</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
            <ul class="dropdown-content">
                <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                <li><a href="training_list.php">Trainings</a></li>
                <li><a href="add_training.php">Add Training</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Branch / Location ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_branch.php">Add Branch / Location</a></li>
                <li><a href="branch_list.php">Branch / Location List</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_performance.php">Add Evaluation</a></li>
                <li><a href="performance_list.php">Evaluations</a></li>
            </ul>
        </li>

    </ul>
</div>

<!-- Main Content -->
<div class="main-content">
    <h3>Assign Employee Benefits</h3>

    <?php if ($message): ?><div class="alert success"><?= $message ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert error"><?= $error ?></div><?php endif; ?>

    <form method="POST" class="form-container">
        <label for="emp_id">Employee</label>
        <select name="emp_id" id="emp_id" required>
            <option value="">Select Employee</option>
            <?php while ($row = $employees->fetch_assoc()): ?>
                <option value="<?= $row['emp_id'] ?>"><?= htmlspecialchars($row['full_name']) ?></option>
            <?php endwhile; ?>
        </select>

        <label for="health_plan">Health Plan</label>
        <input type="text" name="health_plan" id="health_plan" placeholder="e.g., Standard HMO">

        <label for="retirement_plan">Retirement Plan</label>
        <input type="text" name="retirement_plan" id="retirement_plan" placeholder="e.g., 401(k)">

        <label for="insurance_type">Insurance Type</label>
        <input type="text" name="insurance_type" id="insurance_type" placeholder="e.g., Life, Accident, Health">

        <label for="dependents">Dependents</label>
        <input type="number" name="dependents" id="dependents" min="0" value="0">

        <button type="submit" class="btn">Assign Benefits</button>
    </form>
</div>

<!-- Logout Confirmation Modal -->
<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.preventDefault();

    document.querySelectorAll('.dropdown').forEach(drop => {
        if (!drop.contains(event.target)) {
            drop.classList.remove('active');
        }
    });

    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}
const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

// Open modal
logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

// Close modal
closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

// Confirm logout
confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

// Close modal if user clicks outside the modal content
window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>
