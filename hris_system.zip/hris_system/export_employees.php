<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) exit('Not authorized');

$search = $_GET['search'] ?? '';
$employment_status = $_GET['employment_status'] ?? '';
$employment_type = $_GET['employment_type'] ?? '';
$birthday = $_GET['birthday'] ?? '';

// Define headers explicitly
$headers = [
    'Employee ID', 'Employee No', 'First Name', 'Last Name', 'Address', 'Age', 'Date of Birth',
    'Department', 'Position', 'Civil Status', 'Tax Status', 'TIN No.', 'SSS No.',
    'PhilHealth No.', 'PagIBIG No.', 'Nationality', 'Gender', 'Mobile Number', 'Email',
    'Contact Person', 'Emergency Contact', 'Date Hired', 'Contract End Date',
    'Contract File', 'Image', 'Employment Status', 'Employment Type', 'Branch ID'
];

$query = "SELECT * FROM employees WHERE 1=1";
$params = [];
$types = "";

if ($search) {
    $search_query = "%$search%";
    $query .= " AND (first_name LIKE ? OR last_name LIKE ? OR department LIKE ? OR position LIKE ?)";
    $types .= "ssss";
    array_push($params, $search_query, $search_query, $search_query, $search_query);
}

if ($employment_status) {
    $query .= " AND employment_status = ?";
    $types .= "s";
    array_push($params, $employment_status);
}

if ($employment_type) {
    $query .= " AND employment_type = ?";
    $types .= "s";
    array_push($params, $employment_type);
}

if ($birthday) {
    $query .= " AND date_of_birth = ?";
    $types .= "s";
    array_push($params, $birthday);
}

$stmt = $conn->prepare($query);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
$employees = $result->fetch_all(MYSQLI_ASSOC);

// CSV Export
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="employees.csv"');

$out = fopen('php://output', 'w');

// Always write headers
fputcsv($out, $headers);

// Write rows if there are any
foreach ($employees as $row) {
    // Ensure the CSV columns match the headers
    $rowData = [];
    foreach ($headers as $col) {
        $rowData[] = $row[$col] ?? ''; // empty string if column not set
    }
    fputcsv($out, $rowData);
}

fclose($out);
exit;
?>
