<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['branch_name']);
    $address = trim($_POST['address']);

    if ($name == "") {
        $message = "Branch name is required!";
    } else {
        $stmt = $conn->prepare("INSERT INTO branches (branch_name, address) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $address);

        if ($stmt->execute()) {
            $message = "Branch added successfully!";
        } else {
            $message = "Error saving branch.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Branch</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
</head>
<body>

<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<nav class="sub-navbar">
    <ul class="nav-menu">
        <li><a href="dashboard.php">Dashboard</a></li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_leave.php">Leave Form</a></li>
                <li><a href="leave_requests.php">Leave Requests</a></li>
            </ul>
        </li>

        <!-- <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_payroll.php">Add Payroll</a></li>
                <li><a href="payroll.php">Payroll List</a></li>
                <li><a href="add_benefits.php">Add Benefits</a></li>
                <li><a href="benefits_list.php">Benefits List</a></li>
            </ul>
        </li> -->

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
            <ul class="dropdown-content">
                <li><a href="reports.php">Reports</a></li>
                <li><a href="accounts.php">Accounts</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_job.php">Job Opening</a></li>
                <li><a href="job_list.php">Job List</a></li>
                <li><a href="add_candidate.php">Add Candidate</a></li>
                <li><a href="candidate_list.php">Candidates</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
            <ul class="dropdown-content">
                <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                <li><a href="training_list.php">Trainings</a></li>
                <li><a href="add_training.php">Add Training</a></li>
            </ul>
        </li>

        <li class="dropdown active">
            <a href="#" class="active" onclick="toggleDropdown(event)">Branch / Location ▾</a>
            <ul class="dropdown-content" style="display:block;">
                <li><a href="add_branch.php" class="active">Add Branch / Location</a></li>
                <li><a href="branch_list.php">Branch / Location List</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_performance.php">Add Evaluation</a></li>
                <li><a href="performance_list.php">Evaluation List</a></li>
            </ul>
        </li>
    </ul>
</nav>

<div class="main-content">
    <h2>Add Branch / Location</h2>

    <?php if ($message): ?>
        <p style="color:green;"><?= htmlspecialchars($message); ?></p>
    <?php endif; ?>

    <form method="POST">
        <label>Branch Name</label>
        <input type="text" name="branch_name" required>

        <label>Address</label>
        <input type="text" name="address" required>

        <button type="submit" class="btn">Save Branch</button>
    </form>
</div>

<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.preventDefault();
    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
    const content = parent.querySelector('.dropdown-content');
    if (content) {
        content.style.display = content.style.display === 'block' ? 'none' : 'block';
    }
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>
