<?php
echo password_hash('admin123', PASSWORD_DEFAULT);
?>
$2y$10$1/zeyFzWzmELhAea1GJikO1Mev4MJL2r/NbFb6cHNzPaLsGKziC96