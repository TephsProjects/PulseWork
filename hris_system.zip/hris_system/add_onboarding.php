<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Fetch employees
$employees = $conn->query("SELECT emp_id, CONCAT(first_name, ' ', last_name) AS name FROM employees ORDER BY name ASC");

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_employees = isset($_POST['emp_ids']) ? $_POST['emp_ids'] : [];
    $task_name = trim($_POST['task_name']);
    $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
    $status = $_POST['status'] ?? 'Pending';

    if (!empty($selected_employees) && !empty($task_name)) {
        foreach ($selected_employees as $emp_id) {
            $emp_id = intval($emp_id);

            if ($status === 'Completed') {
                // Automatically mark completed_at if task is already completed
                $stmt = $conn->prepare("
                    INSERT INTO onboarding_tasks (emp_id, task_name, due_date, status, completed_at)
                    VALUES (?, ?, ?, ?, CURDATE())
                ");
                $stmt->bind_param("isss", $emp_id, $task_name, $due_date, $status);
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO onboarding_tasks (emp_id, task_name, due_date, status)
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->bind_param("isss", $emp_id, $task_name, $due_date, $status);
            }

            $stmt->execute();
        }

        $message = "✅ Onboarding task assigned successfully!";
    } else {
        $message = "⚠️ Please fill in all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Onboarding Task</title>
<link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
<link rel="stylesheet" href="assets/css/style.css">
<style>
    body {
        background: #f4f6f8;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .main-content {
        padding: 30px 20px;
        background-color: #f8f9fc;
        min-height: calc(100vh - 120px);
    }

    .form-container {
        background: #fff;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        max-width: 700px;
        margin: 20px auto;
    }

    label {
        display: block;
        margin-top: 12px;
        font-weight: bold;
    }

    select, input[type="text"], input[type="date"] {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        border-radius: 6px;
        border: 1px solid #ccc;
    }

    select[multiple] {
        height: 150px;
    }

    button {
        margin-top: 20px;
        padding: 10px 18px;
        background: #007bff;
        border: none;
        color: #fff;
        border-radius: 6px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    button:hover {
        background: #0056b3;
    }

    .message {
        margin: 10px 0;
        padding: 10px;
        border-radius: 6px;
        font-weight: bold;
    }

    .message.success {
        background: #d4edda;
        color: #155724;
    }

    .message.error {
        background: #f8d7da;
        color: #721c24;
    }
</style>
</head>
<body>
<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?php echo $_SESSION['full_name']; ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<!-- Sub-navbar -->
<div class="sub-navbar">
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>

        <!-- Leave -->
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_leave.php">Leave Form</a></li>
                <li><a href="leave_requests.php">Leave Requests</a></li>
            </ul>
        </li>

        <!-- Payroll 
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_payroll.php">Add Payroll</a></li>
                <li><a href="payroll.php">Payroll List</a></li>
                <li><a href="add_benefits.php">Add Benefits</a></li>
                <li><a href="benefits_list.php">Benefits List</a></li>
            </ul>
        </li> -->

        <!-- Reports & Accounts -->
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
            <ul class="dropdown-content">
                <li><a href="reports.php">Reports</a></li>
                <li><a href="accounts.php">Accounts</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
            </ul>
        </li>

        <!-- Recruitment -->
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_job.php">Add Job Opening</a></li>
                <li><a href="job_list.php">Job Openings</a></li>
                <li><a href="add_candidate.php">Add Candidate</a></li>
                <li><a href="candidate_list.php">Candidates</a></li>
            </ul>
        </li>

        <!-- Training / Onboarding -->
        <li class="dropdown">
            <a href="#" class="active" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
            <ul class="dropdown-content">
                <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                <li><a href="add_onboarding.php" class="active">Add Onboarding Task</a></li>
                <li><a href="training_list.php">Trainings</a></li>
                <li><a href="add_training.php">Add Training</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Branch / Location ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_branch.php">Add Branch / Location</a></li>
                <li><a href="branch_list.php">Branch / Location List</a></li>
            </ul>
        </li>

        <!-- Performance -->
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_performance.php">Add Evaluation</a></li>
                <li><a href="performance_list.php">Evaluations</a></li>
            </ul>
        </li>
    </ul>
</div>

<!-- ✅ Main Content -->
<div class="main-content">
    <h3>Add Onboarding Task</h3>
    <div class="form-container">
        <?php if ($message): ?>
            <div class="message <?= strpos($message, '✅') !== false ? 'success' : 'error' ?>">
                <?= $message ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <label>Select Employees:</label>
            <select name="emp_ids[]" multiple required>
                <?php while ($emp = $employees->fetch_assoc()): ?>
                    <option value="<?= $emp['emp_id'] ?>"><?= htmlspecialchars($emp['name']) ?></option>
                <?php endwhile; ?>
            </select>
            <small style="color:gray;">Hold CTRL (Windows) or CMD (Mac) to select multiple employees</small>

            <label>Task Name:</label>
            <input type="text" name="task_name" placeholder="e.g., Submit company documents" required>

            <label>Due Date:</label>
            <input type="date" name="due_date" required>

            <label>Status:</label>
            <select name="status">
                <option value="Pending" selected>Pending</option>
                <option value="Completed">Completed</option>
            </select>

            <button type="submit">Add Task</button>
        </form>
    </div>
</div>

<!-- Logout Confirmation Modal -->
<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.preventDefault();
    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

// Open modal
logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

// Close modal
closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

// Confirm logout
confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

// Close modal if user clicks outside the modal content
window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>
