<?php
session_start();
require __DIR__ . '/fpdf/fpdf.php';
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    exit('Unauthorized');
}

if (!isset($_GET['id'])) {
    exit('Employee ID missing');
}

/* ================= HR USER ================= */
$hrStmt = $conn->prepare("
    SELECT full_name, role 
    FROM users 
    WHERE id = ?
");
$hrStmt->bind_param("i", $_SESSION['user_id']);
$hrStmt->execute();
$hrResult = $hrStmt->get_result();

if ($hrResult->num_rows === 0) {
    exit('HR user not found');
}

$hr = $hrResult->fetch_assoc();

$id = (int)$_GET['id'];

$stmt = $conn->prepare("
    SELECT first_name, last_name, position, department, date_hired, employment_status
    FROM employees
    WHERE emp_id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    exit('Employee not found');
}

$emp = $result->fetch_assoc();

$fullName = $emp['first_name'] . ' ' . $emp['last_name'];

/* ================= PDF ================= */

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetMargins(25, 25, 25);
$pdf->SetAutoPageBreak(true, 25);

/* ---------- Header ---------- */
$pdf->Image('assets/images/PulseWork-logo.png', 85, 15, 40);
$pdf->Ln(41);

$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 8, 'PULSEWORK', 0, 1, 'C');

$pdf->SetFont('Arial', '', 11);
$pdf->Cell(0, 6, 'Human Resource Information System', 0, 1, 'C');

$pdf->Ln(5);
$pdf->SetDrawColor(0, 0, 0);
$pdf->Line(25, $pdf->GetY(), 185, $pdf->GetY());
$pdf->Ln(15);

/* ---------- Title ---------- */
$pdf->SetFont('Arial', 'B', 15);
$pdf->Cell(0, 10, 'CERTIFICATE OF EMPLOYMENT', 0, 1, 'C');
$pdf->Ln(10);

/* ---------- Body ---------- */
$pdf->SetFont('Arial', '', 12);

$bodyText = "This is to certify that {$fullName} is presently employed with PulseWork "
          . "in the capacity of {$emp['position']} under the {$emp['department']} Department.\n\n"
          . "The employee commenced employment on "
          . date('F d, Y', strtotime($emp['date_hired'])) . " and is currently holding a "
          . "{$emp['employment_status']} employment status.\n\n"
          . "This certification is issued upon the request of the above-named employee "
          . "for whatever lawful purpose it may serve.";

$pdf->MultiCell(0, 8, $bodyText, 0, 'J');
$pdf->Ln(20);

/* ---------- Signature ---------- */
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 8, 'Issued this ' . date('jS') . ' day of ' . date('F Y') . '.', 0, 1);
$pdf->Ln(25);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(80, 8, '_____________________________', 0, 1);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(80, 6, strtoupper($hr['full_name']), 0, 1);

$pdf->SetFont('Arial', '', 11);
$pdf->Cell(80, 6, $hr['role'], 0, 1);

/* ---------- Output ---------- */
$pdf->Output('I', 'Certificate_of_Employment.pdf');
exit;
