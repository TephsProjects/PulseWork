<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM employees WHERE emp_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Employee not found.";
    exit();
}

$emp = $result->fetch_assoc();

$performance = [];
$perfStmt = $conn->prepare("
    SELECT evaluation_period, evaluator, rating, comments, created_at
    FROM performance
    WHERE emp_id = ?
    ORDER BY created_at DESC
");
$perfStmt->bind_param("i", $id);
$perfStmt->execute();
$perfResult = $perfStmt->get_result();

while ($row = $perfResult->fetch_assoc()) {
    $performance[] = $row;
}

$branches = [];
$branchQuery = $conn->query("SELECT * FROM branches ORDER BY branch_name ASC");
while ($b = $branchQuery->fetch_assoc()) {
    $branches[] = $b;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Details</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/employee_view.css">
</head>
<body>
    <div class="navbar">
        <h2>PulseWork: HR Information System</h2>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
            <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
        </div>
    </div>

    <nav class="sub-navbar">
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_leave.php">Leave Form</a></li>
                    <li><a href="leave_requests.php">Leave Requests</a></li>
                </ul>
            </li>

            <!-- <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_payroll.php">Add Payroll</a></li>
                    <li><a href="payroll.php">Payroll List</a></li>
                    <li><a href="add_benefits.php">Add Benefits</a></li>
                    <li><a href="benefits_list.php">Benefits List</a></li>
                </ul>
            </li> -->

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
                <ul class="dropdown-content">
                    <li><a href="reports.php">Reports</a></li>
                    <li><a href="accounts.php">Accounts</a></li>
                    <li><a href="add_employee.php">Add Employee</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_job.php">Job Opening</a></li>
                    <li><a href="job_list.php">Job List</a></li>
                    <li><a href="add_candidate.php">Add Candidate</a></li>
                    <li><a href="candidate_list.php">Candidates</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Training ▾</a>
                <ul class="dropdown-content">
                    <li><a href="training_list.php">Trainings</a></li>
                    <li><a href="add_training.php">Add Training</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Location ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_performance.php">Add Evaluation</a></li>
                    <li><a href="performance_list.php">Evaluation List</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <?php if (isset($_GET['updated'])): ?>
        <div style="padding:10px; background:#d4edda; color:black; border-radius:5px; margin-bottom:15px;">
            ✅ Branch updated successfully!
        </div>
    <?php endif; ?>

    <div class="main-content">
        <div class="employee-profile">
            <div class="employee-header">
                <img src="<?php echo !empty($emp['image']) ? 'uploads/' . htmlspecialchars($emp['image']) : 'assets/images/default.png'; ?>" alt="Employee Image">

                <div class="info">
                    <h2><?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?></h2>
                    <p><strong>Employee No:</strong> <?php echo htmlspecialchars($emp['employee_no']); ?></p>
                    <p><strong><?php echo htmlspecialchars($emp['position']); ?></strong> — <?php echo htmlspecialchars($emp['department']); ?></p>
                    <p>Hired: <?php echo htmlspecialchars($emp['date_hired']); ?></p>
                </div>

                <div class="coe-actions">
                    <a href="generate_coe.php?id=<?php echo $emp['emp_id']; ?>" 
                    class="coe-btn" 
                    target="_blank">
                        📄 Generate COE
                    </a>
                </div>
            </div>

            <div class="employee-body">
                <div class="info-section">
                    <h3>Personal Information</h3>
                    <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($emp['date_of_birth']); ?></p>
                    <p><strong>Gender:</strong> <?php echo htmlspecialchars($emp['gender']); ?></p>
                    <p><strong>Civil Status:</strong> <?php echo htmlspecialchars($emp['civil_status']); ?></p>
                    <p><strong>Nationality:</strong> <?php echo htmlspecialchars($emp['nationality']); ?></p>
                    <p><strong>Address:</strong> <?php echo htmlspecialchars($emp['address']); ?></p>
                </div>

                <div class="info-section">
                    <h3>Contact Information</h3>
                    <p><strong>Mobile:</strong> <?php echo htmlspecialchars($emp['mobile_number']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($emp['email']); ?></p>
                    <p><strong>Contact Person:</strong> <?php echo htmlspecialchars($emp['contact_person']); ?></p>
                    <p><strong>Emergency Contact:</strong> <?php echo htmlspecialchars($emp['emergency_contact']); ?></p>
                </div>

                <div class="info-section">
                    <h3>Employment Details</h3>
                    <p><strong>Department:</strong> <?php echo htmlspecialchars($emp['department']); ?></p>
                    <p><strong>Position:</strong> <?php echo htmlspecialchars($emp['position']); ?></p>
                    <p><strong>Tax Status:</strong> <?php echo htmlspecialchars($emp['tax_status']); ?></p>
                    <p><strong>Date Hired:</strong> <?php echo htmlspecialchars($emp['date_hired']); ?></p>
                    <p><strong>Contract End Date:</strong> 
                        <?php 
                            if (!empty($emp['contract_end_date'])) {
                                echo htmlspecialchars($emp['contract_end_date']);
                                $today = new DateTime();
                                $end = new DateTime($emp['contract_end_date']);
                                $diff = $today->diff($end)->days;
                                if ($end < $today) {
                                    echo " <span style='color:red;'>(Expired)</span>";
                                } elseif ($diff <= 30) {
                                    echo " <span style='color:orange;'>(Expiring soon)</span>";
                                }
                            } else {
                                echo "<span style='color:gray;'>No contract end date</span>";
                            }
                        ?>
                    </p>
                    <p><strong>Contract File:</strong> 
                        <?php if (!empty($emp['contract_file'])): ?>
                            <a href="<?php echo htmlspecialchars($emp['contract_file']); ?>" target="_blank" style="color:#007bff;">📄 View Contract</a>
                        <?php else: ?>
                            <span style="color:gray;">No file uploaded</span>
                        <?php endif; ?>
                    </p>
                </div>
                
                <div class="info-section">
                    <h3>Employment Status & Type</h3>
                    
                    <p><strong>Employment Status:</strong> 
                        <?php echo !empty($emp['employment_status']) ? htmlspecialchars($emp['employment_status']) : '<span style="color:gray;">Not set</span>'; ?>
                    </p>

                    <p><strong>Employment Type:</strong> 
                        <?php echo !empty($emp['employment_type']) ? htmlspecialchars($emp['employment_type']) : '<span style="color:gray;">Not set</span>'; ?>
                    </p>

                    <form method="POST" action="update_employment.php" style="margin-top:10px;">

                        <input type="hidden" name="emp_id" value="<?php echo $emp['emp_id']; ?>">

                        <p><strong>Update Status:</strong></p>
                        <select name="employment_status" class="form-control" style="padding:8px; width:100%; max-width:300px; margin-bottom:10px;">
                            <option value="">-- Select Status --</option>
                            <?php 
                                $statuses = ["Active", "Probationary", "Resigned", "Terminated", "AWOL", "End of Contract"];
                                foreach ($statuses as $st):
                            ?>
                                <option value="<?php echo $st; ?>" 
                                    <?php echo ($emp['employment_status'] == $st) ? 'selected' : ''; ?>>
                                    <?php echo $st; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                        <p><strong>Update Employment Type:</strong></p>
                        <select name="employment_type" class="form-control" style="padding:8px; width:100%; max-width:300px; margin-bottom:10px;">
                            <option value="">-- Select Type --</option>
                            <?php 
                                $types = ["Full-time", "Part-time", "Contractual", "Project-based", "Probationary"];
                                foreach ($types as $tp):
                            ?>
                                <option value="<?php echo $tp; ?>" 
                                    <?php echo ($emp['employment_type'] == $tp) ? 'selected' : ''; ?>>
                                    <?php echo $tp; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                        <button type="submit" class="update-btn" style="margin-top:10px; background:#007bff;">
                            💾 Update Info
                        </button>
                    </form>
                </div>

                <div class="info-section">
                    <h3>Government IDs</h3>

                    <p><strong>TIN No.:</strong> <?php echo htmlspecialchars($emp['tin_no']); ?></p>
                    <p><strong>SSS No.:</strong> <?php echo htmlspecialchars($emp['sss_no']); ?></p>
                    <p><strong>PhilHealth No.:</strong> <?php echo htmlspecialchars($emp['philhealth_no']); ?></p>

                    <h3>Uploaded Documents</h3>

                    <p><strong>SSS File:</strong> 
                        <?php if (!empty($emp['sss_file'])): ?>
                            <a href="<?php echo 'uploads/sss/' . htmlspecialchars($emp['sss_file']); ?>" target="_blank" style="color:#007bff;">📄 View File</a>
                        <?php else: ?>
                            <span style="color:gray;">No file uploaded</span>
                        <?php endif; ?>
                    </p>

                    <p><strong>PhilHealth File:</strong> 
                        <?php if (!empty($emp['philhealth_file'])): ?>
                            <a href="<?php echo 'uploads/philhealth/' . htmlspecialchars($emp['philhealth_file']); ?>" target="_blank" style="color:#007bff;">📄 View File</a>
                        <?php else: ?>
                            <span style="color:gray;">No file uploaded</span>
                        <?php endif; ?>
                    </p>

                    <p><strong>Pag-IBIG File:</strong> 
                        <?php if (!empty($emp['pagibig_file'])): ?>
                            <a href="<?php echo 'uploads/pagibig/' . htmlspecialchars($emp['pagibig_file']); ?>" target="_blank" style="color:#007bff;">📄 View File</a>
                        <?php else: ?>
                            <span style="color:gray;">No file uploaded</span>
                        <?php endif; ?>
                    </p>

                    <p><strong>NBI Clearance:</strong> 
                        <?php if (!empty($emp['nbi_file'])): ?>
                            <a href="<?php echo 'uploads/nbi/' . htmlspecialchars($emp['nbi_file']); ?>" target="_blank" style="color:#007bff;">📄 View File</a>
                        <?php else: ?>
                            <span style="color:gray;">No file uploaded</span>
                        <?php endif; ?>
                    </p>
                </div>

                <div class="info-section">
                    <h3>Branch / Location</h3>

                    <form method="POST" action="update_branch.php">
                        <input type="hidden" name="emp_id" value="<?php echo $emp['emp_id']; ?>">

                        <p><strong>Assigned Branch:</strong></p>

                        <select name="branch_id" class="form-control" style="padding:8px; width:100%; max-width:300px;">
                            <option value="">-- Select Branch --</option>

                            <?php foreach ($branches as $br): ?>
                                <option value="<?php echo $br['branch_id']; ?>"
                                    <?php echo ($emp['branch_id'] == $br['branch_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($br['branch_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                        <button type="submit" class="update-btn">
                            💾 Update Branch
                        </button>
                    </form>
                </div>

                <div class="info-section">
                    <h3>Performance Evaluations</h3>

                    <?php if (!empty($performance)): ?>
                        <div class="performance-list">

                            <?php foreach ($performance as $perf): ?>
                                <div class="performance-card">
                                    <div class="performance-header">
                                        <strong><?php echo htmlspecialchars($perf['evaluation_period']); ?></strong>
                                        <span class="performance-date">
                                            <?php echo date('M d, Y', strtotime($perf['created_at'])); ?>
                                        </span>
                                    </div>

                                    <p>
                                        <strong>Evaluator:</strong>
                                        <?php echo htmlspecialchars($perf['evaluator']); ?>
                                    </p>

                                    <p>
                                        <strong>Rating:</strong>
                                        <?php
                                            if ($perf['rating'] !== null) {
                                                $rating = (float)$perf['rating'];

                                                if ($rating >= 4) {
                                                    $color = '#28a745'; 
                                                    $label = 'Excellent';
                                                } elseif ($rating >= 3) {
                                                    $color = '#ffc107'; 
                                                    $label = 'Satisfactory';
                                                } else {
                                                    $color = '#dc3545'; 
                                                    $label = 'Needs Improvement';
                                                }

                                                echo "<span class='rating-badge' style='background:$color'>
                                                        $rating – $label
                                                    </span>";
                                            } else {
                                                echo "<span style='color:gray;'>Not rated</span>";
                                            }
                                        ?>
                                    </p>

                                    <?php if (!empty($perf['comments'])): ?>
                                        <div class="performance-comments">
                                            <strong>Comments:</strong>
                                            <p><?php echo nl2br(htmlspecialchars($perf['comments'])); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>

                        </div>
                    <?php else: ?>
                        <p style="color:gray;">No performance evaluations recorded.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="footer-actions">
                <a href="edit_employee.php?id=<?php echo $emp['emp_id']; ?>" class="back-btn" style="background:#28a745;">✏️ Edit</a>
                <a href="delete_employee.php?id=<?php echo $emp['emp_id']; ?>" 
                class="back-btn" 
                style="background:#dc3545;"
                onclick="return confirm('Are you sure you want to delete this employee?');">🗑 Delete</a>
                <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
            </div>
        </div>
    </div>

    <div id="logoutModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to logout?</p>
            <div class="modal-buttons">
                <button id="confirmLogout" class="btn">Yes, Logout</button>
                <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
            </div>
        </div>
    </div>

<script>
function toggleDropdown(event) {
    event.preventDefault();

    document.querySelectorAll('.dropdown').forEach(drop => {
        if (!drop.contains(event.target)) {
            drop.classList.remove('active');
        }
    });

    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>