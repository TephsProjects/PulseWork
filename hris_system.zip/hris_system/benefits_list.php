<?php
session_start();
include('includes/db.php');
if (!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }

$query = "SELECT b.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name 
          FROM benefits b 
          JOIN employees e ON b.emp_id = e.emp_id 
          ORDER BY b.date_assigned DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Benefits List</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<div class="sub-navbar">
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_leave.php">Leave Form</a></li>
                <li><a href="leave_requests.php">Leave Requests</a></li>
            </ul>
        </li>

        <!-- <li class="dropdown">
            <a href="#" class="active" onclick="toggleDropdown(event)">Payroll ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_payroll.php">Add Payroll</a></li>
                <li><a href="payroll.php">Payroll List</a></li>
                <li><a href="add_benefits.php">Add Benefits</a></li>
                <li><a href="benefits_list.php" class="active">Benefits List</a></li>
            </ul>
        </li> -->

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_job.php">Add Job</a></li>
                <li><a href="job_list.php">Jobs</a></li>
                <li><a href="add_candidate.php">Add Candidate</a></li>
                <li><a href="candidate_list.php">Candidates</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
            <ul class="dropdown-content">
                <li><a href="reports.php">Reports</a></li>
                <li><a href="accounts.php">Accounts</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
            <ul class="dropdown-content">
                <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                <li><a href="training_list.php">Trainings</a></li>
                <li><a href="add_training.php">Add Training</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_performance.php">Add Evaluation</a></li>
                <li><a href="performance_list.php">Evaluations</a></li>
            </ul>
        </li>
    </ul>
</div>

<!-- Main Content -->
<div class="main-content">
    <h3>Employee Benefits</h3>
    <table class="styled-table">
        <thead>
            <tr>
                <th>Employee</th>
                <th>Health Plan</th>
                <th>Retirement Plan</th>
                <th>Insurance</th>
                <th>Dependents</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['employee_name']) ?></td>
                <td><?= htmlspecialchars($row['health_plan']) ?></td>
                <td><?= htmlspecialchars($row['retirement_plan']) ?></td>
                <td><?= htmlspecialchars($row['insurance_type']) ?></td>
                <td><?= htmlspecialchars($row['dependents']) ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Logout Confirmation Modal -->
<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.preventDefault();

    document.querySelectorAll('.dropdown').forEach(drop => {
        if (!drop.contains(event.target)) {
            drop.classList.remove('active');
        }
    });

    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

// Open modal
logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

// Close modal
closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

// Confirm logout
confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

// Close modal if user clicks outside the modal content
window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>
